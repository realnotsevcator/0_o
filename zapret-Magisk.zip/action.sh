#!/system/bin/bash
MODPATH=/data/adb/modules/zapret

echo "***********************"
echo "*       zapret        *"
echo "***********************"

su -c "$MODPATH/system/bin/zapret toggle"
