#!/system/bin/sh

MODPATH=/data/adb/modules/zapret
su -c "$MODPATH/zapret.sh"
